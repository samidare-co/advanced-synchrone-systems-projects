#ifndef ASCII_H
#define ASCII_H

char* ascii_print(unsigned char uc) ;

#endif
