
#ifndef FILEB_TYPES_H
#define FILEB_TYPES_H 

#include <stdlib.h> 
#include <stdio.h> 

#endif 
